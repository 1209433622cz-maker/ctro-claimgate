# CTRO RP V5.1 — Tier A synthetic reproduction

This is a self-contained input packet for **fixed-ID replay, complete aggregate-table readback, seven synthetic figure reconstructions and deterministic analytical explanation**. It contains virtual data, not patient matrices or PBC derivative scores. It is not a journal submission or a fully repeated 960000-instance experiment.

## Run

Extract into a new directory, with Python 3.12.14 and the versions in `requirements.txt` already installed. No network/data request is needed by the script. The historical frozen numerical environment is checked strictly; a different runtime must be documented and tested rather than silently accepted.

```powershell
python -I 2_code/77_analytic_portable/portable_replay.py
```

Results appear in `reproduction_output`. The script forbids network calls and access to the original project directory through Python audit events. Dependencies use the installed Python runtime; this is not a container, clean OS image or demonstrated cross-platform distribution.

## What is tested

- 576 **existing** IDs: replicate 0, 2499 and 4999 in each frozen scenario. Input SHA, metadata and method results must match saved canonical fixtures. Replayed computation is not new scientific replication or an independent implementation of the generator.
- All 192 scenario summaries, joined against all 4608 target, 384 FDR and 2304 paired rows with numerical tolerance. It is not new readback of all raw records.
- Original Figure2/Figure3 and supplementary S1–S5 are drawn using unchanged plotting instructions. PNG/SVG bytes and numerical panel rows are checked against canonical bindings. Source JSON differs because the source scope/adapter are now explicit. Original Figure1 (contains the PBC overview) and Figure4 are excluded.
- Exact mask distributions, 640 fixed-count variance decompositions, 1280 descriptive correspondence rows and C population/finite-n expectations. The variance decomposition does not prove exact Welch coverage or introduce a corrected interval.

## Explicit adapters

Original `model.py`, `numerics.py`, `main_runner.py` and `build_figures.py` are copied byte-for-byte. The replay entry point injects the extracted runtime root and a **package** identity guard. Historical full-workspace freeze records are retained as provenance, not falsely asserted to have all their dependencies inside this packet. Only the original plotting main's patient setup, PBC overview and patient figure blocks are excluded; those exact cuts are recorded. Originals in the source workspace were not edited.

## Full simulation and optional real illustration

The generator and inference code are present, but the command above does not reconstruct the 979-MB raw archive or certify that a newly timed full rerun has identical gzip hashes. Runtime fields differ on re-execution. Any later full rerun should use a separately documented runner/output policy and compare input identities/numerical fields, not timing bytes.

Tier B (the prior PBC illustration) stays local and optional pending rights confirmation. It is not needed for Tier A; do not download human data, contact authors, request access or infer redistribution rights to make this packet run. Original four PBC maxT P-values remain 1.0 in the local manuscript. Third-party article files, skill bundles, owner identities and patient-derived inputs are excluded.

## Limits and licensing

Original bounded continuous model: anonymous modules K=5/11/16/17; sparse direct signal only in M1 K=5; random shared masks; two simple Welch analyses. Not a count/rank benchmark, universal organelle scoring method, biological validation or new causal mechanism. Development exposure and historical frozen status are unchanged.

This is a local author-review/reproducibility artifact. Owner code/figure license and public-release decisions are pending; possession of this ZIP is not blanket permission to redistribute third-party resources. No GitHub push or submission occurred as part of preparation.
